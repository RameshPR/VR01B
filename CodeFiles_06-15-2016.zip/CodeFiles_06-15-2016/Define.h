#include "Models.h"
#include "Arrays.h"

namespace Inventum_VR
{
	extern Model model;
	extern Model_010_140 model_010_140;
	extern Model_030_040 model_030_040;
	extern Model_040_050 model_040_050;
	extern Model_050_060 model_050_060;
	extern Model_060_070 model_060_070;
	extern Model_070_080 model_070_080;
	extern Model_080_090 model_080_090;
	extern Model_090_100 model_090_100;
	extern Model_100_110 model_100_110;
	extern Model_110_120 model_110_120;
	extern Model_120_130 model_120_130;
	extern Model_130_140 model_130_140;
	extern Model_140_150 model_140_150;
	extern Model_150_160 model_150_160;
	extern Model_160_170 model_160_170;
	extern Model_170_180 model_170_180;
	extern Model_180_190 model_180_190;

	extern AFib1_Arrays_010_140 aFib1_Arrays_010_140;
	extern AFib1_Arrays_030_040 aFib1_Arrays_030_040;
	extern AFib1_Arrays_040_050 aFib1_Arrays_040_050;
	extern AFib1_Arrays_050_060 aFib1_Arrays_050_060;
	extern AFib1_Arrays_060_070 aFib1_Arrays_060_070;
	extern AFib1_Arrays_070_080 aFib1_Arrays_070_080;
	extern AFib1_Arrays_080_090 aFib1_Arrays_080_090;
	extern AFib1_Arrays_090_100 aFib1_Arrays_090_100;
	extern AFib1_Arrays_100_110 aFib1_Arrays_100_110;
	extern AFib1_Arrays_110_120 aFib1_Arrays_110_120;
	extern AFib1_Arrays_120_130 aFib1_Arrays_120_130;
	extern AFib1_Arrays_130_140 aFib1_Arrays_130_140;
	extern AFib1_Arrays_140_150 aFib1_Arrays_140_150;
	extern AFib1_Arrays_150_160 aFib1_Arrays_150_160;
	extern AFib1_Arrays_160_170 aFib1_Arrays_160_170;
	extern AFib1_Arrays_170_180 aFib1_Arrays_170_180;
	extern AFib1_Arrays_180_190 aFib1_Arrays_180_190;

	extern AFib2_Arrays_010_140 aFib2_Arrays_010_140;
	extern AFib2_Arrays_030_040 aFib2_Arrays_030_040;
	extern AFib2_Arrays_040_050 aFib2_Arrays_040_050;
	extern AFib2_Arrays_050_060 aFib2_Arrays_050_060;
	extern AFib2_Arrays_060_070 aFib2_Arrays_060_070;
	extern AFib2_Arrays_070_080 aFib2_Arrays_070_080;
	extern AFib2_Arrays_080_090 aFib2_Arrays_080_090;
	extern AFib2_Arrays_090_100 aFib2_Arrays_090_100;
	extern AFib2_Arrays_100_110 aFib2_Arrays_100_110;
	extern AFib2_Arrays_110_120 aFib2_Arrays_110_120;
	extern AFib2_Arrays_120_130 aFib2_Arrays_120_130;
	extern AFib2_Arrays_130_140 aFib2_Arrays_130_140;
	extern AFib2_Arrays_140_150 aFib2_Arrays_140_150;
	extern AFib2_Arrays_150_160 aFib2_Arrays_150_160;
	extern AFib2_Arrays_160_170 aFib2_Arrays_160_170;
	extern AFib2_Arrays_170_180 aFib2_Arrays_170_180;
	extern AFib2_Arrays_180_190 aFib2_Arrays_180_190;

	extern AFib3_Arrays_010_140 aFib3_Arrays_010_140;
	extern AFib3_Arrays_030_040 aFib3_Arrays_030_040;
	extern AFib3_Arrays_040_050 aFib3_Arrays_040_050;
	extern AFib3_Arrays_050_060 aFib3_Arrays_050_060;
	extern AFib3_Arrays_060_070 aFib3_Arrays_060_070;
	extern AFib3_Arrays_070_080 aFib3_Arrays_070_080;
	extern AFib3_Arrays_080_090 aFib3_Arrays_080_090;
	extern AFib3_Arrays_090_100 aFib3_Arrays_090_100;
	extern AFib3_Arrays_100_110 aFib3_Arrays_100_110;
	extern AFib3_Arrays_110_120 aFib3_Arrays_110_120;
	extern AFib3_Arrays_120_130 aFib3_Arrays_120_130;
	extern AFib3_Arrays_130_140 aFib3_Arrays_130_140;
	extern AFib3_Arrays_140_150 aFib3_Arrays_140_150;
	extern AFib3_Arrays_150_160 aFib3_Arrays_150_160;
	extern AFib3_Arrays_160_170 aFib3_Arrays_160_170;
	extern AFib3_Arrays_170_180 aFib3_Arrays_170_180;
	extern AFib3_Arrays_180_190 aFib3_Arrays_180_190;
}