namespace Inventum_VR
{
	//Deallocate the arrays
	void DeallocateArrays();
}