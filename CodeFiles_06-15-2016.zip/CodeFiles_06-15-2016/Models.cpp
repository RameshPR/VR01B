#include "Models.h"
#include "Define.h"

namespace Inventum_VR
{

	void Model_AssignSegment_010_140(Model model)
	{
		model_010_140.positions = model.positions;
		model_010_140.texels = model.texels;
		model_010_140.normals = model.normals;
		model_010_140.faces = model.faces;
		model_010_140.verticies = model.verticies;
	}

	void Model_AssignSegment_030_040(Model model)
	{
		model_030_040.positions = model.positions;
		model_030_040.texels = model.texels;
		model_030_040.normals = model.normals;
		model_030_040.faces = model.faces;
		model_030_040.verticies = model.verticies;
	}

	void Model_AssignSegment_040_050(Model model)
	{
		model_040_050.positions = model.positions;
		model_040_050.texels = model.texels;
		model_040_050.normals = model.normals;
		model_040_050.faces = model.faces;
		model_040_050.verticies = model.verticies;
	}

	void Model_AssignSegment_050_060(Model model)
	{
		model_050_060.positions = model.positions;
		model_050_060.texels = model.texels;
		model_050_060.normals = model.normals;
		model_050_060.faces = model.faces;
		model_050_060.verticies = model.verticies;
	}

	void Model_AssignSegment_060_070(Model model)
	{
		model_060_070.positions = model.positions;
		model_060_070.texels = model.texels;
		model_060_070.normals = model.normals;
		model_060_070.faces = model.faces;
		model_060_070.verticies = model.verticies;
	}

	void Model_AssignSegment_070_080(Model model)
	{
		model_070_080.positions = model.positions;
		model_070_080.texels = model.texels;
		model_070_080.normals = model.normals;
		model_070_080.faces = model.faces;
		model_070_080.verticies = model.verticies;
	}

	void Model_AssignSegment_080_090(Model model)
	{
		model_080_090.positions = model.positions;
		model_080_090.texels = model.texels;
		model_080_090.normals = model.normals;
		model_080_090.faces = model.faces;
		model_080_090.verticies = model.verticies;
	}

	void Model_AssignSegment_090_100(Model model)
	{
		model_090_100.positions = model.positions;
		model_090_100.texels = model.texels;
		model_090_100.normals = model.normals;
		model_090_100.faces = model.faces;
		model_090_100.verticies = model.verticies;
	}

	void Model_AssignSegment_100_110(Model model)
	{
		model_100_110.positions = model.positions;
		model_100_110.texels = model.texels;
		model_100_110.normals = model.normals;
		model_100_110.faces = model.faces;
		model_100_110.verticies = model.verticies;
	}

	void Model_AssignSegment_110_120(Model model)
	{
		model_110_120.positions = model.positions;
		model_110_120.texels = model.texels;
		model_110_120.normals = model.normals;
		model_110_120.faces = model.faces;
		model_110_120.verticies = model.verticies;
	}

	void Model_AssignSegment_120_130(Model model)
	{
		model_120_130.positions = model.positions;
		model_120_130.texels = model.texels;
		model_120_130.normals = model.normals;
		model_120_130.faces = model.faces;
		model_120_130.verticies = model.verticies;
	}

	void Model_AssignSegment_130_140(Model model)
	{
		model_130_140.positions = model.positions;
		model_130_140.texels = model.texels;
		model_130_140.normals = model.normals;
		model_130_140.faces = model.faces;
		model_130_140.verticies = model.verticies;
	}

	void Model_AssignSegment_140_150(Model model)
	{
		model_140_150.positions = model.positions;
		model_140_150.texels = model.texels;
		model_140_150.normals = model.normals;
		model_140_150.faces = model.faces;
		model_140_150.verticies = model.verticies;
	}

	void Model_AssignSegment_150_160(Model model)
	{
		model_150_160.positions = model.positions;
		model_150_160.texels = model.texels;
		model_150_160.normals = model.normals;
		model_150_160.faces = model.faces;
		model_150_160.verticies = model.verticies;
	}

	void Model_AssignSegment_160_170(Model model)
	{
		model_160_170.positions = model.positions;
		model_160_170.texels = model.texels;
		model_160_170.normals = model.normals;
		model_160_170.faces = model.faces;
		model_160_170.verticies = model.verticies;
	}

	void Model_AssignSegment_170_180(Model model)
	{
		model_170_180.positions = model.positions;
		model_170_180.texels = model.texels;
		model_170_180.normals = model.normals;
		model_170_180.faces = model.faces;
		model_170_180.verticies = model.verticies;
	}

	void Model_AssignSegment_180_190(Model model)
	{
		model_180_190.positions = model.positions;
		model_180_190.texels = model.texels;
		model_180_190.normals = model.normals;
		model_180_190.faces = model.faces;
		model_180_190.verticies = model.verticies;
	}

}