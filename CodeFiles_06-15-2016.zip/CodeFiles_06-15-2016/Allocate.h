#include "Models.h"

namespace Inventum_VR
{
	void GetOBJInfo(string value, string segmentStart, string segmentFinish);
	void AllocateModelsAndArrays(string name, string fileName, string fileSegmentStart, string fileSegmentFinish);
	void AllocateAFib1(string name, string fileSegmentStart, string fileSegmentFinish);
	void AllocateAFib2(string name, string fileSegmentStart, string fileSegmentFinish);
	void AllocateAFib3(string name, string fileSegmentStart, string fileSegmentFinish);
}