#include "Deallocate.h"
#include "Define.h"

namespace Inventum_VR
{
	//Deallocate the arrays
	void DeallocateArrays()
	{
		/*
		//Deallocate the memory spaces
		for (int i = 0; i < model.positions; i++)
		{
		delete[] positions[i];
		}
		delete[] positions;

		for (int i = 0; i < model.texels; i++)
		{
		delete[] texels[i];
		}
		delete[] texels;

		for (int i = 0; i < model.normals; i++)
		{
		delete[] normals[i];
		}
		delete[] normals;

		for (int i = 0; i < model.faces; i++)
		{
		delete[] faces[i];
		}
		delete[] faces;
		*/
	}
}
