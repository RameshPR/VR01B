#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <string>

#include "Arrays.h"
#include "Define.h"

using namespace std;

namespace Inventum_VR
{
	//Get the obj Data
	void GetOBJData(string file, string segmentStart, string segmentFinish, double** positions, double** texels, double** normals, int** faces)
	{
		cout << "Get OBJ data for " << file << " - " << segmentStart << endl;

		int pCount = 0, tCount = 0, nCount = 0, fCount = 0;

		bool allowReading = false;

		ifstream stream;
		stream.open(file);

		if (!stream.good())
		{
			cout << "File is corrupt or some error opening the OBJ file";
			getchar();
			exit(EXIT_FAILURE);
		}

		//Parse through the file and get the number of vertices, normals, faces and so on
		while (!stream.eof())
		{
			string line;
			getline(stream, line);

			if (line.compare(segmentFinish) == 0)
				break;
			else if (line.compare(segmentStart) == 0 || allowReading)
			{
				allowReading = true;

				string type = line.substr(0, 2);

				if (type.compare("v ") == 0 && positions != NULL && pCount < model.positions)
				{
					//Copy the entire line
					char* l = new char[line.size() + 1];
					memcpy(l, line.c_str(), line.size() + 1);

					strtok(l, " ");
					for (int i = 0; i < 3; i++)
						positions[pCount][i] = atof(strtok(NULL, " "));

					//deallocate the memory
					delete[] l;
					pCount++;
				}

				else if (type.compare("vt") == 0 && texels != NULL && tCount < model.texels)
				{
					//Copy the entire line
					char* l = new char[line.size() + 1];
					memcpy(l, line.c_str(), line.size() + 1);

					strtok(l, " ");
					for (int i = 0; i < 2; i++)
						texels[tCount][i] = atof(strtok(NULL, " "));

					//deallocate the memory
					delete[] l;
					tCount++;
				}

				else if (type.compare("vn") == 0 && normals != NULL && nCount < model.normals)
				{
					//Copy the entire line
					char* l = new char[line.size() + 1];
					memcpy(l, line.c_str(), line.size() + 1);

					strtok(l, " ");
					for (int i = 0; i < 3; i++)
						normals[nCount][i] = atof(strtok(NULL, " "));

					//deallocate the memory
					delete[] l;
					nCount++;
				}

				else if (type.compare("f ") == 0 && faces != NULL && fCount < model.faces)
				{
					//Copy the entire line
					char* l = new char[line.size() + 1];
					memcpy(l, line.c_str(), line.size() + 1);

					strtok(l, " ");
					for (int i = 0; i < 6; i++)
						faces[fCount][i] = atof(strtok(NULL, " //"));

					//deallocate the memory
					delete[] l;
					fCount++;
				}
			}
		}

		stream.close();
	}

	#pragma region AFib1_Array_Segments

	//Assigning the AFib1 array segments
	void AFib1_AssignSegment_010_140(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_010_140.Positions_010_140 = new double*[model.positions];
		aFib1_Arrays_010_140.Texels_010_140 = new double*[model.texels];
		aFib1_Arrays_010_140.Normals_010_140 = new double*[model.normals];
		aFib1_Arrays_010_140.Faces_010_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_010_140.Positions_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_010_140.Positions_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_010_140.Texels_010_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_010_140.Texels_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_010_140.Normals_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_010_140.Normals_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_010_140.Faces_010_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_010_140.Faces_010_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_010_140.Positions_010_140, aFib1_Arrays_010_140.Texels_010_140, aFib1_Arrays_010_140.Normals_010_140, aFib1_Arrays_010_140.Faces_010_140);
	}

	void AFib1_AssignSegment_030_040(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_030_040.Positions_030_040 = new double*[model.positions];
		aFib1_Arrays_030_040.Texels_030_040 = new double*[model.texels];
		aFib1_Arrays_030_040.Normals_030_040 = new double*[model.normals];
		aFib1_Arrays_030_040.Faces_030_040 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_030_040.Positions_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_030_040.Positions_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_030_040.Texels_030_040[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_030_040.Texels_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_030_040.Normals_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_030_040.Normals_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_030_040.Faces_030_040[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_030_040.Faces_030_040[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_030_040.Positions_030_040, aFib1_Arrays_030_040.Texels_030_040, aFib1_Arrays_030_040.Normals_030_040, aFib1_Arrays_030_040.Faces_030_040);
	}

	void AFib1_AssignSegment_040_050(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_040_050.Positions_040_050 = new double*[model.positions];
		aFib1_Arrays_040_050.Texels_040_050 = new double*[model.texels];
		aFib1_Arrays_040_050.Normals_040_050 = new double*[model.normals];
		aFib1_Arrays_040_050.Faces_040_050 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_040_050.Positions_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_040_050.Positions_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_040_050.Texels_040_050[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_040_050.Texels_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_040_050.Normals_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_040_050.Normals_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_040_050.Faces_040_050[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_040_050.Faces_040_050[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_040_050.Positions_040_050, aFib1_Arrays_040_050.Texels_040_050, aFib1_Arrays_040_050.Normals_040_050, aFib1_Arrays_040_050.Faces_040_050);
	}

	void AFib1_AssignSegment_050_060(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_050_060.Positions_050_060 = new double*[model.positions];
		aFib1_Arrays_050_060.Texels_050_060 = new double*[model.texels];
		aFib1_Arrays_050_060.Normals_050_060 = new double*[model.normals];
		aFib1_Arrays_050_060.Faces_050_060 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_050_060.Positions_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_050_060.Positions_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_050_060.Texels_050_060[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_050_060.Texels_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_050_060.Normals_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_050_060.Normals_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_050_060.Faces_050_060[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_050_060.Faces_050_060[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_050_060.Positions_050_060, aFib1_Arrays_050_060.Texels_050_060, aFib1_Arrays_050_060.Normals_050_060, aFib1_Arrays_050_060.Faces_050_060);
	}

	void AFib1_AssignSegment_060_070(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_060_070.Positions_060_070 = new double*[model.positions];
		aFib1_Arrays_060_070.Texels_060_070 = new double*[model.texels];
		aFib1_Arrays_060_070.Normals_060_070 = new double*[model.normals];
		aFib1_Arrays_060_070.Faces_060_070 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_060_070.Positions_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_060_070.Positions_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_060_070.Texels_060_070[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_060_070.Texels_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_060_070.Normals_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_060_070.Normals_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_060_070.Faces_060_070[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_060_070.Faces_060_070[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_060_070.Positions_060_070, aFib1_Arrays_060_070.Texels_060_070, aFib1_Arrays_060_070.Normals_060_070, aFib1_Arrays_060_070.Faces_060_070);
	}

	void AFib1_AssignSegment_070_080(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_070_080.Positions_070_080 = new double*[model.positions];
		aFib1_Arrays_070_080.Texels_070_080 = new double*[model.texels];
		aFib1_Arrays_070_080.Normals_070_080 = new double*[model.normals];
		aFib1_Arrays_070_080.Faces_070_080 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_070_080.Positions_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_070_080.Positions_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_070_080.Texels_070_080[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_070_080.Texels_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_070_080.Normals_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_070_080.Normals_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_070_080.Faces_070_080[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_070_080.Faces_070_080[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_070_080.Positions_070_080, aFib1_Arrays_070_080.Texels_070_080, aFib1_Arrays_070_080.Normals_070_080, aFib1_Arrays_070_080.Faces_070_080);
	}

	void AFib1_AssignSegment_080_090(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_080_090.Positions_080_090 = new double*[model.positions];
		aFib1_Arrays_080_090.Texels_080_090 = new double*[model.texels];
		aFib1_Arrays_080_090.Normals_080_090 = new double*[model.normals];
		aFib1_Arrays_080_090.Faces_080_090 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_080_090.Positions_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_080_090.Positions_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_080_090.Texels_080_090[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_080_090.Texels_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_080_090.Normals_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_080_090.Normals_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_080_090.Faces_080_090[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_080_090.Faces_080_090[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_080_090.Positions_080_090, aFib1_Arrays_080_090.Texels_080_090, aFib1_Arrays_080_090.Normals_080_090, aFib1_Arrays_080_090.Faces_080_090);
	}

	void AFib1_AssignSegment_090_100(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_090_100.Positions_090_100 = new double*[model.positions];
		aFib1_Arrays_090_100.Texels_090_100 = new double*[model.texels];
		aFib1_Arrays_090_100.Normals_090_100 = new double*[model.normals];
		aFib1_Arrays_090_100.Faces_090_100 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_090_100.Positions_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_090_100.Positions_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_090_100.Texels_090_100[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_090_100.Texels_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_090_100.Normals_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_090_100.Normals_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_090_100.Faces_090_100[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_090_100.Faces_090_100[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_090_100.Positions_090_100, aFib1_Arrays_090_100.Texels_090_100, aFib1_Arrays_090_100.Normals_090_100, aFib1_Arrays_090_100.Faces_090_100);
	}

	void AFib1_AssignSegment_100_110(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_100_110.Positions_100_110 = new double*[model.positions];
		aFib1_Arrays_100_110.Texels_100_110 = new double*[model.texels];
		aFib1_Arrays_100_110.Normals_100_110 = new double*[model.normals];
		aFib1_Arrays_100_110.Faces_100_110 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_100_110.Positions_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_100_110.Positions_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_100_110.Texels_100_110[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_100_110.Texels_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_100_110.Normals_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_100_110.Normals_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_100_110.Faces_100_110[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_100_110.Faces_100_110[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_100_110.Positions_100_110, aFib1_Arrays_100_110.Texels_100_110, aFib1_Arrays_100_110.Normals_100_110, aFib1_Arrays_100_110.Faces_100_110);
	}

	void AFib1_AssignSegment_110_120(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_110_120.Positions_110_120 = new double*[model.positions];
		aFib1_Arrays_110_120.Texels_110_120 = new double*[model.texels];
		aFib1_Arrays_110_120.Normals_110_120 = new double*[model.normals];
		aFib1_Arrays_110_120.Faces_110_120 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_110_120.Positions_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_110_120.Positions_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_110_120.Texels_110_120[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_110_120.Texels_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_110_120.Normals_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_110_120.Normals_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_110_120.Faces_110_120[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_110_120.Faces_110_120[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_110_120.Positions_110_120, aFib1_Arrays_110_120.Texels_110_120, aFib1_Arrays_110_120.Normals_110_120, aFib1_Arrays_110_120.Faces_110_120);
	}

	void AFib1_AssignSegment_120_130(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_120_130.Positions_120_130 = new double*[model.positions];
		aFib1_Arrays_120_130.Texels_120_130 = new double*[model.texels];
		aFib1_Arrays_120_130.Normals_120_130 = new double*[model.normals];
		aFib1_Arrays_120_130.Faces_120_130 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_120_130.Positions_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_120_130.Positions_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_120_130.Texels_120_130[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_120_130.Texels_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_120_130.Normals_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_120_130.Normals_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_120_130.Faces_120_130[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_120_130.Faces_120_130[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_120_130.Positions_120_130, aFib1_Arrays_120_130.Texels_120_130, aFib1_Arrays_120_130.Normals_120_130, aFib1_Arrays_120_130.Faces_120_130);
	}

	void AFib1_AssignSegment_130_140(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_130_140.Positions_130_140 = new double*[model.positions];
		aFib1_Arrays_130_140.Texels_130_140 = new double*[model.texels];
		aFib1_Arrays_130_140.Normals_130_140 = new double*[model.normals];
		aFib1_Arrays_130_140.Faces_130_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_130_140.Positions_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_130_140.Positions_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_130_140.Texels_130_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_130_140.Texels_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_130_140.Normals_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_130_140.Normals_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_130_140.Faces_130_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_130_140.Faces_130_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_130_140.Positions_130_140, aFib1_Arrays_130_140.Texels_130_140, aFib1_Arrays_130_140.Normals_130_140, aFib1_Arrays_130_140.Faces_130_140);
	}

	void AFib1_AssignSegment_140_150(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_140_150.Positions_140_150 = new double*[model.positions];
		aFib1_Arrays_140_150.Texels_140_150 = new double*[model.texels];
		aFib1_Arrays_140_150.Normals_140_150 = new double*[model.normals];
		aFib1_Arrays_140_150.Faces_140_150 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_140_150.Positions_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_140_150.Positions_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_140_150.Texels_140_150[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_140_150.Texels_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_140_150.Normals_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_140_150.Normals_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_140_150.Faces_140_150[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_140_150.Faces_140_150[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_140_150.Positions_140_150, aFib1_Arrays_140_150.Texels_140_150, aFib1_Arrays_140_150.Normals_140_150, aFib1_Arrays_140_150.Faces_140_150);
	}

	void AFib1_AssignSegment_150_160(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_150_160.Positions_150_160 = new double*[model.positions];
		aFib1_Arrays_150_160.Texels_150_160 = new double*[model.texels];
		aFib1_Arrays_150_160.Normals_150_160 = new double*[model.normals];
		aFib1_Arrays_150_160.Faces_150_160 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_150_160.Positions_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_150_160.Positions_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_150_160.Texels_150_160[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_150_160.Texels_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_150_160.Normals_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_150_160.Normals_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_150_160.Faces_150_160[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_150_160.Faces_150_160[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_150_160.Positions_150_160, aFib1_Arrays_150_160.Texels_150_160, aFib1_Arrays_150_160.Normals_150_160, aFib1_Arrays_150_160.Faces_150_160);
	}

	void AFib1_AssignSegment_160_170(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_160_170.Positions_160_170 = new double*[model.positions];
		aFib1_Arrays_160_170.Texels_160_170 = new double*[model.texels];
		aFib1_Arrays_160_170.Normals_160_170 = new double*[model.normals];
		aFib1_Arrays_160_170.Faces_160_170 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_160_170.Positions_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_160_170.Positions_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_160_170.Texels_160_170[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_160_170.Texels_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_160_170.Normals_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_160_170.Normals_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_160_170.Faces_160_170[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_160_170.Faces_160_170[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_160_170.Positions_160_170, aFib1_Arrays_160_170.Texels_160_170, aFib1_Arrays_160_170.Normals_160_170, aFib1_Arrays_160_170.Faces_160_170);
	}

	void AFib1_AssignSegment_170_180(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_170_180.Positions_170_180 = new double*[model.positions];
		aFib1_Arrays_170_180.Texels_170_180 = new double*[model.texels];
		aFib1_Arrays_170_180.Normals_170_180 = new double*[model.normals];
		aFib1_Arrays_170_180.Faces_170_180 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_170_180.Positions_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_170_180.Positions_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_170_180.Texels_170_180[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_170_180.Texels_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_170_180.Normals_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_170_180.Normals_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_170_180.Faces_170_180[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_170_180.Faces_170_180[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_170_180.Positions_170_180, aFib1_Arrays_170_180.Texels_170_180, aFib1_Arrays_170_180.Normals_170_180, aFib1_Arrays_170_180.Faces_170_180);
	}

	void AFib1_AssignSegment_180_190(string file, string segmentStart, string segmentFinish)
	{
		aFib1_Arrays_180_190.Positions_180_190 = new double*[model.positions];
		aFib1_Arrays_180_190.Texels_180_190 = new double*[model.texels];
		aFib1_Arrays_180_190.Normals_180_190 = new double*[model.normals];
		aFib1_Arrays_180_190.Faces_180_190 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib1_Arrays_180_190.Positions_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_180_190.Positions_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib1_Arrays_180_190.Texels_180_190[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib1_Arrays_180_190.Texels_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib1_Arrays_180_190.Normals_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib1_Arrays_180_190.Normals_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib1_Arrays_180_190.Faces_180_190[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib1_Arrays_180_190.Faces_180_190[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib1_Arrays_180_190.Positions_180_190, aFib1_Arrays_180_190.Texels_180_190, aFib1_Arrays_180_190.Normals_180_190, aFib1_Arrays_180_190.Faces_180_190);
	}

	#pragma endregion AFib1_Array_Segments

	#pragma region AFib2_Array_Segments

	//Assigning the AFib2 array segments
	void AFib2_AssignSegment_010_140(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_010_140.Positions_010_140 = new double*[model.positions];
		aFib2_Arrays_010_140.Texels_010_140 = new double*[model.texels];
		aFib2_Arrays_010_140.Normals_010_140 = new double*[model.normals];
		aFib2_Arrays_010_140.Faces_010_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_010_140.Positions_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_010_140.Positions_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_010_140.Texels_010_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_010_140.Texels_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_010_140.Normals_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_010_140.Normals_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_010_140.Faces_010_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_010_140.Faces_010_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_010_140.Positions_010_140, aFib2_Arrays_010_140.Texels_010_140, aFib2_Arrays_010_140.Normals_010_140, aFib2_Arrays_010_140.Faces_010_140);
	}

	void AFib2_AssignSegment_030_040(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_030_040.Positions_030_040 = new double*[model.positions];
		aFib2_Arrays_030_040.Texels_030_040 = new double*[model.texels];
		aFib2_Arrays_030_040.Normals_030_040 = new double*[model.normals];
		aFib2_Arrays_030_040.Faces_030_040 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_030_040.Positions_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_030_040.Positions_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_030_040.Texels_030_040[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_030_040.Texels_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_030_040.Normals_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_030_040.Normals_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_030_040.Faces_030_040[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_030_040.Faces_030_040[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_030_040.Positions_030_040, aFib2_Arrays_030_040.Texels_030_040, aFib2_Arrays_030_040.Normals_030_040, aFib2_Arrays_030_040.Faces_030_040);
	}

	void AFib2_AssignSegment_040_050(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_040_050.Positions_040_050 = new double*[model.positions];
		aFib2_Arrays_040_050.Texels_040_050 = new double*[model.texels];
		aFib2_Arrays_040_050.Normals_040_050 = new double*[model.normals];
		aFib2_Arrays_040_050.Faces_040_050 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_040_050.Positions_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_040_050.Positions_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_040_050.Texels_040_050[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_040_050.Texels_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_040_050.Normals_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_040_050.Normals_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_040_050.Faces_040_050[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_040_050.Faces_040_050[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_040_050.Positions_040_050, aFib2_Arrays_040_050.Texels_040_050, aFib2_Arrays_040_050.Normals_040_050, aFib2_Arrays_040_050.Faces_040_050);
	}

	void AFib2_AssignSegment_050_060(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_050_060.Positions_050_060 = new double*[model.positions];
		aFib2_Arrays_050_060.Texels_050_060 = new double*[model.texels];
		aFib2_Arrays_050_060.Normals_050_060 = new double*[model.normals];
		aFib2_Arrays_050_060.Faces_050_060 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_050_060.Positions_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_050_060.Positions_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_050_060.Texels_050_060[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_050_060.Texels_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_050_060.Normals_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_050_060.Normals_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_050_060.Faces_050_060[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_050_060.Faces_050_060[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_050_060.Positions_050_060, aFib2_Arrays_050_060.Texels_050_060, aFib2_Arrays_050_060.Normals_050_060, aFib2_Arrays_050_060.Faces_050_060);
	}

	void AFib2_AssignSegment_060_070(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_060_070.Positions_060_070 = new double*[model.positions];
		aFib2_Arrays_060_070.Texels_060_070 = new double*[model.texels];
		aFib2_Arrays_060_070.Normals_060_070 = new double*[model.normals];
		aFib2_Arrays_060_070.Faces_060_070 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_060_070.Positions_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_060_070.Positions_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_060_070.Texels_060_070[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_060_070.Texels_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_060_070.Normals_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_060_070.Normals_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_060_070.Faces_060_070[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_060_070.Faces_060_070[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_060_070.Positions_060_070, aFib2_Arrays_060_070.Texels_060_070, aFib2_Arrays_060_070.Normals_060_070, aFib2_Arrays_060_070.Faces_060_070);
	}

	void AFib2_AssignSegment_070_080(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_070_080.Positions_070_080 = new double*[model.positions];
		aFib2_Arrays_070_080.Texels_070_080 = new double*[model.texels];
		aFib2_Arrays_070_080.Normals_070_080 = new double*[model.normals];
		aFib2_Arrays_070_080.Faces_070_080 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_070_080.Positions_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_070_080.Positions_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_070_080.Texels_070_080[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_070_080.Texels_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_070_080.Normals_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_070_080.Normals_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_070_080.Faces_070_080[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_070_080.Faces_070_080[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_070_080.Positions_070_080, aFib2_Arrays_070_080.Texels_070_080, aFib2_Arrays_070_080.Normals_070_080, aFib2_Arrays_070_080.Faces_070_080);
	}

	void AFib2_AssignSegment_080_090(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_080_090.Positions_080_090 = new double*[model.positions];
		aFib2_Arrays_080_090.Texels_080_090 = new double*[model.texels];
		aFib2_Arrays_080_090.Normals_080_090 = new double*[model.normals];
		aFib2_Arrays_080_090.Faces_080_090 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_080_090.Positions_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_080_090.Positions_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_080_090.Texels_080_090[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_080_090.Texels_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_080_090.Normals_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_080_090.Normals_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_080_090.Faces_080_090[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_080_090.Faces_080_090[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_080_090.Positions_080_090, aFib2_Arrays_080_090.Texels_080_090, aFib2_Arrays_080_090.Normals_080_090, aFib2_Arrays_080_090.Faces_080_090);
	}

	void AFib2_AssignSegment_090_100(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_090_100.Positions_090_100 = new double*[model.positions];
		aFib2_Arrays_090_100.Texels_090_100 = new double*[model.texels];
		aFib2_Arrays_090_100.Normals_090_100 = new double*[model.normals];
		aFib2_Arrays_090_100.Faces_090_100 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_090_100.Positions_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_090_100.Positions_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_090_100.Texels_090_100[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_090_100.Texels_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_090_100.Normals_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_090_100.Normals_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_090_100.Faces_090_100[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_090_100.Faces_090_100[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_090_100.Positions_090_100, aFib2_Arrays_090_100.Texels_090_100, aFib2_Arrays_090_100.Normals_090_100, aFib2_Arrays_090_100.Faces_090_100);
	}

	void AFib2_AssignSegment_100_110(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_100_110.Positions_100_110 = new double*[model.positions];
		aFib2_Arrays_100_110.Texels_100_110 = new double*[model.texels];
		aFib2_Arrays_100_110.Normals_100_110 = new double*[model.normals];
		aFib2_Arrays_100_110.Faces_100_110 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_100_110.Positions_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_100_110.Positions_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_100_110.Texels_100_110[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_100_110.Texels_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_100_110.Normals_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_100_110.Normals_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_100_110.Faces_100_110[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_100_110.Faces_100_110[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_100_110.Positions_100_110, aFib2_Arrays_100_110.Texels_100_110, aFib2_Arrays_100_110.Normals_100_110, aFib2_Arrays_100_110.Faces_100_110);
	}

	void AFib2_AssignSegment_110_120(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_110_120.Positions_110_120 = new double*[model.positions];
		aFib2_Arrays_110_120.Texels_110_120 = new double*[model.texels];
		aFib2_Arrays_110_120.Normals_110_120 = new double*[model.normals];
		aFib2_Arrays_110_120.Faces_110_120 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_110_120.Positions_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_110_120.Positions_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_110_120.Texels_110_120[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_110_120.Texels_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_110_120.Normals_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_110_120.Normals_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_110_120.Faces_110_120[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_110_120.Faces_110_120[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_110_120.Positions_110_120, aFib2_Arrays_110_120.Texels_110_120, aFib2_Arrays_110_120.Normals_110_120, aFib2_Arrays_110_120.Faces_110_120);
	}

	void AFib2_AssignSegment_120_130(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_120_130.Positions_120_130 = new double*[model.positions];
		aFib2_Arrays_120_130.Texels_120_130 = new double*[model.texels];
		aFib2_Arrays_120_130.Normals_120_130 = new double*[model.normals];
		aFib2_Arrays_120_130.Faces_120_130 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_120_130.Positions_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_120_130.Positions_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_120_130.Texels_120_130[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_120_130.Texels_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_120_130.Normals_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_120_130.Normals_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_120_130.Faces_120_130[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_120_130.Faces_120_130[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_120_130.Positions_120_130, aFib2_Arrays_120_130.Texels_120_130, aFib2_Arrays_120_130.Normals_120_130, aFib2_Arrays_120_130.Faces_120_130);
	}

	void AFib2_AssignSegment_130_140(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_130_140.Positions_130_140 = new double*[model.positions];
		aFib2_Arrays_130_140.Texels_130_140 = new double*[model.texels];
		aFib2_Arrays_130_140.Normals_130_140 = new double*[model.normals];
		aFib2_Arrays_130_140.Faces_130_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_130_140.Positions_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_130_140.Positions_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_130_140.Texels_130_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_130_140.Texels_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_130_140.Normals_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_130_140.Normals_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_130_140.Faces_130_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_130_140.Faces_130_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_130_140.Positions_130_140, aFib2_Arrays_130_140.Texels_130_140, aFib2_Arrays_130_140.Normals_130_140, aFib2_Arrays_130_140.Faces_130_140);
	}

	void AFib2_AssignSegment_140_150(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_140_150.Positions_140_150 = new double*[model.positions];
		aFib2_Arrays_140_150.Texels_140_150 = new double*[model.texels];
		aFib2_Arrays_140_150.Normals_140_150 = new double*[model.normals];
		aFib2_Arrays_140_150.Faces_140_150 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_140_150.Positions_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_140_150.Positions_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_140_150.Texels_140_150[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_140_150.Texels_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_140_150.Normals_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_140_150.Normals_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_140_150.Faces_140_150[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_140_150.Faces_140_150[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_140_150.Positions_140_150, aFib2_Arrays_140_150.Texels_140_150, aFib2_Arrays_140_150.Normals_140_150, aFib2_Arrays_140_150.Faces_140_150);
	}

	void AFib2_AssignSegment_150_160(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_150_160.Positions_150_160 = new double*[model.positions];
		aFib2_Arrays_150_160.Texels_150_160 = new double*[model.texels];
		aFib2_Arrays_150_160.Normals_150_160 = new double*[model.normals];
		aFib2_Arrays_150_160.Faces_150_160 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_150_160.Positions_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_150_160.Positions_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_150_160.Texels_150_160[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_150_160.Texels_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_150_160.Normals_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_150_160.Normals_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_150_160.Faces_150_160[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_150_160.Faces_150_160[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_150_160.Positions_150_160, aFib2_Arrays_150_160.Texels_150_160, aFib2_Arrays_150_160.Normals_150_160, aFib2_Arrays_150_160.Faces_150_160);
	}

	void AFib2_AssignSegment_160_170(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_160_170.Positions_160_170 = new double*[model.positions];
		aFib2_Arrays_160_170.Texels_160_170 = new double*[model.texels];
		aFib2_Arrays_160_170.Normals_160_170 = new double*[model.normals];
		aFib2_Arrays_160_170.Faces_160_170 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_160_170.Positions_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_160_170.Positions_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_160_170.Texels_160_170[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_160_170.Texels_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_160_170.Normals_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_160_170.Normals_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_160_170.Faces_160_170[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_160_170.Faces_160_170[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_160_170.Positions_160_170, aFib2_Arrays_160_170.Texels_160_170, aFib2_Arrays_160_170.Normals_160_170, aFib2_Arrays_160_170.Faces_160_170);
	}

	void AFib2_AssignSegment_170_180(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_170_180.Positions_170_180 = new double*[model.positions];
		aFib2_Arrays_170_180.Texels_170_180 = new double*[model.texels];
		aFib2_Arrays_170_180.Normals_170_180 = new double*[model.normals];
		aFib2_Arrays_170_180.Faces_170_180 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_170_180.Positions_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_170_180.Positions_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_170_180.Texels_170_180[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_170_180.Texels_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_170_180.Normals_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_170_180.Normals_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_170_180.Faces_170_180[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_170_180.Faces_170_180[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_170_180.Positions_170_180, aFib2_Arrays_170_180.Texels_170_180, aFib2_Arrays_170_180.Normals_170_180, aFib2_Arrays_170_180.Faces_170_180);
	}

	void AFib2_AssignSegment_180_190(string file, string segmentStart, string segmentFinish)
	{
		aFib2_Arrays_180_190.Positions_180_190 = new double*[model.positions];
		aFib2_Arrays_180_190.Texels_180_190 = new double*[model.texels];
		aFib2_Arrays_180_190.Normals_180_190 = new double*[model.normals];
		aFib2_Arrays_180_190.Faces_180_190 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib2_Arrays_180_190.Positions_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_180_190.Positions_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib2_Arrays_180_190.Texels_180_190[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib2_Arrays_180_190.Texels_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib2_Arrays_180_190.Normals_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib2_Arrays_180_190.Normals_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib2_Arrays_180_190.Faces_180_190[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib2_Arrays_180_190.Faces_180_190[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib2_Arrays_180_190.Positions_180_190, aFib2_Arrays_180_190.Texels_180_190, aFib2_Arrays_180_190.Normals_180_190, aFib2_Arrays_180_190.Faces_180_190);
	}

	#pragma endregion AFib2_Array_Segments

	#pragma region AFib3_Array_Segments

	//Assigning the AFib3 array segments
	void AFib3_AssignSegment_010_140(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_010_140.Positions_010_140 = new double*[model.positions];
		aFib3_Arrays_010_140.Texels_010_140 = new double*[model.texels];
		aFib3_Arrays_010_140.Normals_010_140 = new double*[model.normals];
		aFib3_Arrays_010_140.Faces_010_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_010_140.Positions_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_010_140.Positions_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_010_140.Texels_010_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_010_140.Texels_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_010_140.Normals_010_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_010_140.Normals_010_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_010_140.Faces_010_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_010_140.Faces_010_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_010_140.Positions_010_140, aFib3_Arrays_010_140.Texels_010_140, aFib3_Arrays_010_140.Normals_010_140, aFib3_Arrays_010_140.Faces_010_140);
	}

	void AFib3_AssignSegment_030_040(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_030_040.Positions_030_040 = new double*[model.positions];
		aFib3_Arrays_030_040.Texels_030_040 = new double*[model.texels];
		aFib3_Arrays_030_040.Normals_030_040 = new double*[model.normals];
		aFib3_Arrays_030_040.Faces_030_040 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_030_040.Positions_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_030_040.Positions_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_030_040.Texels_030_040[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_030_040.Texels_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_030_040.Normals_030_040[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_030_040.Normals_030_040[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_030_040.Faces_030_040[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_030_040.Faces_030_040[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_030_040.Positions_030_040, aFib3_Arrays_030_040.Texels_030_040, aFib3_Arrays_030_040.Normals_030_040, aFib3_Arrays_030_040.Faces_030_040);
	}

	void AFib3_AssignSegment_040_050(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_040_050.Positions_040_050 = new double*[model.positions];
		aFib3_Arrays_040_050.Texels_040_050 = new double*[model.texels];
		aFib3_Arrays_040_050.Normals_040_050 = new double*[model.normals];
		aFib3_Arrays_040_050.Faces_040_050 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_040_050.Positions_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_040_050.Positions_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_040_050.Texels_040_050[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_040_050.Texels_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_040_050.Normals_040_050[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_040_050.Normals_040_050[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_040_050.Faces_040_050[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_040_050.Faces_040_050[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_040_050.Positions_040_050, aFib3_Arrays_040_050.Texels_040_050, aFib3_Arrays_040_050.Normals_040_050, aFib3_Arrays_040_050.Faces_040_050);
	}

	void AFib3_AssignSegment_050_060(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_050_060.Positions_050_060 = new double*[model.positions];
		aFib3_Arrays_050_060.Texels_050_060 = new double*[model.texels];
		aFib3_Arrays_050_060.Normals_050_060 = new double*[model.normals];
		aFib3_Arrays_050_060.Faces_050_060 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_050_060.Positions_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_050_060.Positions_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_050_060.Texels_050_060[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_050_060.Texels_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_050_060.Normals_050_060[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_050_060.Normals_050_060[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_050_060.Faces_050_060[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_050_060.Faces_050_060[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_050_060.Positions_050_060, aFib3_Arrays_050_060.Texels_050_060, aFib3_Arrays_050_060.Normals_050_060, aFib3_Arrays_050_060.Faces_050_060);
	}

	void AFib3_AssignSegment_060_070(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_060_070.Positions_060_070 = new double*[model.positions];
		aFib3_Arrays_060_070.Texels_060_070 = new double*[model.texels];
		aFib3_Arrays_060_070.Normals_060_070 = new double*[model.normals];
		aFib3_Arrays_060_070.Faces_060_070 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_060_070.Positions_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_060_070.Positions_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_060_070.Texels_060_070[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_060_070.Texels_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_060_070.Normals_060_070[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_060_070.Normals_060_070[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_060_070.Faces_060_070[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_060_070.Faces_060_070[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_060_070.Positions_060_070, aFib3_Arrays_060_070.Texels_060_070, aFib3_Arrays_060_070.Normals_060_070, aFib3_Arrays_060_070.Faces_060_070);
	}

	void AFib3_AssignSegment_070_080(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_070_080.Positions_070_080 = new double*[model.positions];
		aFib3_Arrays_070_080.Texels_070_080 = new double*[model.texels];
		aFib3_Arrays_070_080.Normals_070_080 = new double*[model.normals];
		aFib3_Arrays_070_080.Faces_070_080 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_070_080.Positions_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_070_080.Positions_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_070_080.Texels_070_080[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_070_080.Texels_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_070_080.Normals_070_080[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_070_080.Normals_070_080[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_070_080.Faces_070_080[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_070_080.Faces_070_080[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_070_080.Positions_070_080, aFib3_Arrays_070_080.Texels_070_080, aFib3_Arrays_070_080.Normals_070_080, aFib3_Arrays_070_080.Faces_070_080);
	}

	void AFib3_AssignSegment_080_090(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_080_090.Positions_080_090 = new double*[model.positions];
		aFib3_Arrays_080_090.Texels_080_090 = new double*[model.texels];
		aFib3_Arrays_080_090.Normals_080_090 = new double*[model.normals];
		aFib3_Arrays_080_090.Faces_080_090 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_080_090.Positions_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_080_090.Positions_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_080_090.Texels_080_090[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_080_090.Texels_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_080_090.Normals_080_090[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_080_090.Normals_080_090[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_080_090.Faces_080_090[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_080_090.Faces_080_090[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_080_090.Positions_080_090, aFib3_Arrays_080_090.Texels_080_090, aFib3_Arrays_080_090.Normals_080_090, aFib3_Arrays_080_090.Faces_080_090);
	}

	void AFib3_AssignSegment_090_100(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_090_100.Positions_090_100 = new double*[model.positions];
		aFib3_Arrays_090_100.Texels_090_100 = new double*[model.texels];
		aFib3_Arrays_090_100.Normals_090_100 = new double*[model.normals];
		aFib3_Arrays_090_100.Faces_090_100 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_090_100.Positions_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_090_100.Positions_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_090_100.Texels_090_100[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_090_100.Texels_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_090_100.Normals_090_100[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_090_100.Normals_090_100[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_090_100.Faces_090_100[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_090_100.Faces_090_100[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_090_100.Positions_090_100, aFib3_Arrays_090_100.Texels_090_100, aFib3_Arrays_090_100.Normals_090_100, aFib3_Arrays_090_100.Faces_090_100);
	}

	void AFib3_AssignSegment_100_110(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_100_110.Positions_100_110 = new double*[model.positions];
		aFib3_Arrays_100_110.Texels_100_110 = new double*[model.texels];
		aFib3_Arrays_100_110.Normals_100_110 = new double*[model.normals];
		aFib3_Arrays_100_110.Faces_100_110 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_100_110.Positions_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_100_110.Positions_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_100_110.Texels_100_110[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_100_110.Texels_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_100_110.Normals_100_110[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_100_110.Normals_100_110[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_100_110.Faces_100_110[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_100_110.Faces_100_110[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_100_110.Positions_100_110, aFib3_Arrays_100_110.Texels_100_110, aFib3_Arrays_100_110.Normals_100_110, aFib3_Arrays_100_110.Faces_100_110);
	}

	void AFib3_AssignSegment_110_120(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_110_120.Positions_110_120 = new double*[model.positions];
		aFib3_Arrays_110_120.Texels_110_120 = new double*[model.texels];
		aFib3_Arrays_110_120.Normals_110_120 = new double*[model.normals];
		aFib3_Arrays_110_120.Faces_110_120 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_110_120.Positions_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_110_120.Positions_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_110_120.Texels_110_120[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_110_120.Texels_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_110_120.Normals_110_120[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_110_120.Normals_110_120[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_110_120.Faces_110_120[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_110_120.Faces_110_120[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_110_120.Positions_110_120, aFib3_Arrays_110_120.Texels_110_120, aFib3_Arrays_110_120.Normals_110_120, aFib3_Arrays_110_120.Faces_110_120);
	}

	void AFib3_AssignSegment_120_130(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_120_130.Positions_120_130 = new double*[model.positions];
		aFib3_Arrays_120_130.Texels_120_130 = new double*[model.texels];
		aFib3_Arrays_120_130.Normals_120_130 = new double*[model.normals];
		aFib3_Arrays_120_130.Faces_120_130 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_120_130.Positions_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_120_130.Positions_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_120_130.Texels_120_130[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_120_130.Texels_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_120_130.Normals_120_130[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_120_130.Normals_120_130[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_120_130.Faces_120_130[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_120_130.Faces_120_130[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_120_130.Positions_120_130, aFib3_Arrays_120_130.Texels_120_130, aFib3_Arrays_120_130.Normals_120_130, aFib3_Arrays_120_130.Faces_120_130);
	}

	void AFib3_AssignSegment_130_140(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_130_140.Positions_130_140 = new double*[model.positions];
		aFib3_Arrays_130_140.Texels_130_140 = new double*[model.texels];
		aFib3_Arrays_130_140.Normals_130_140 = new double*[model.normals];
		aFib3_Arrays_130_140.Faces_130_140 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_130_140.Positions_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_130_140.Positions_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_130_140.Texels_130_140[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_130_140.Texels_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_130_140.Normals_130_140[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_130_140.Normals_130_140[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_130_140.Faces_130_140[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_130_140.Faces_130_140[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_130_140.Positions_130_140, aFib3_Arrays_130_140.Texels_130_140, aFib3_Arrays_130_140.Normals_130_140, aFib3_Arrays_130_140.Faces_130_140);
	}

	void AFib3_AssignSegment_140_150(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_140_150.Positions_140_150 = new double*[model.positions];
		aFib3_Arrays_140_150.Texels_140_150 = new double*[model.texels];
		aFib3_Arrays_140_150.Normals_140_150 = new double*[model.normals];
		aFib3_Arrays_140_150.Faces_140_150 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_140_150.Positions_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_140_150.Positions_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_140_150.Texels_140_150[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_140_150.Texels_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_140_150.Normals_140_150[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_140_150.Normals_140_150[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_140_150.Faces_140_150[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_140_150.Faces_140_150[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_140_150.Positions_140_150, aFib3_Arrays_140_150.Texels_140_150, aFib3_Arrays_140_150.Normals_140_150, aFib3_Arrays_140_150.Faces_140_150);
	}

	void AFib3_AssignSegment_150_160(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_150_160.Positions_150_160 = new double*[model.positions];
		aFib3_Arrays_150_160.Texels_150_160 = new double*[model.texels];
		aFib3_Arrays_150_160.Normals_150_160 = new double*[model.normals];
		aFib3_Arrays_150_160.Faces_150_160 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_150_160.Positions_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_150_160.Positions_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_150_160.Texels_150_160[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_150_160.Texels_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_150_160.Normals_150_160[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_150_160.Normals_150_160[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_150_160.Faces_150_160[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_150_160.Faces_150_160[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_150_160.Positions_150_160, aFib3_Arrays_150_160.Texels_150_160, aFib3_Arrays_150_160.Normals_150_160, aFib3_Arrays_150_160.Faces_150_160);
	}

	void AFib3_AssignSegment_160_170(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_160_170.Positions_160_170 = new double*[model.positions];
		aFib3_Arrays_160_170.Texels_160_170 = new double*[model.texels];
		aFib3_Arrays_160_170.Normals_160_170 = new double*[model.normals];
		aFib3_Arrays_160_170.Faces_160_170 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_160_170.Positions_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_160_170.Positions_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_160_170.Texels_160_170[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_160_170.Texels_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_160_170.Normals_160_170[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_160_170.Normals_160_170[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_160_170.Faces_160_170[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_160_170.Faces_160_170[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_160_170.Positions_160_170, aFib3_Arrays_160_170.Texels_160_170, aFib3_Arrays_160_170.Normals_160_170, aFib3_Arrays_160_170.Faces_160_170);
	}

	void AFib3_AssignSegment_170_180(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_170_180.Positions_170_180 = new double*[model.positions];
		aFib3_Arrays_170_180.Texels_170_180 = new double*[model.texels];
		aFib3_Arrays_170_180.Normals_170_180 = new double*[model.normals];
		aFib3_Arrays_170_180.Faces_170_180 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_170_180.Positions_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_170_180.Positions_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_170_180.Texels_170_180[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_170_180.Texels_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_170_180.Normals_170_180[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_170_180.Normals_170_180[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_170_180.Faces_170_180[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_170_180.Faces_170_180[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_170_180.Positions_170_180, aFib3_Arrays_170_180.Texels_170_180, aFib3_Arrays_170_180.Normals_170_180, aFib3_Arrays_170_180.Faces_170_180);
	}

	void AFib3_AssignSegment_180_190(string file, string segmentStart, string segmentFinish)
	{
		aFib3_Arrays_180_190.Positions_180_190 = new double*[model.positions];
		aFib3_Arrays_180_190.Texels_180_190 = new double*[model.texels];
		aFib3_Arrays_180_190.Normals_180_190 = new double*[model.normals];
		aFib3_Arrays_180_190.Faces_180_190 = new int*[model.faces];

		if (model.positions != 0)
		{
			for (int i = 0; i < model.positions; i++) //each coordinate in XYZ space
			{
				aFib3_Arrays_180_190.Positions_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_180_190.Positions_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.texels != 0)
		{
			for (int i = 0; i < model.texels; i++) //UV coordinates
			{
				aFib3_Arrays_180_190.Texels_180_190[i] = new double[2];
				for (int j = 0; j < 2; j++)
				{
					aFib3_Arrays_180_190.Texels_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.normals != 0)
		{
			for (int i = 0; i < model.normals; i++) //normal vector
			{
				aFib3_Arrays_180_190.Normals_180_190[i] = new double[3];
				for (int j = 0; j < 3; j++)
				{
					aFib3_Arrays_180_190.Normals_180_190[i][j] = 0.0;
				}
			}
		}

		if (model.faces != 0)
		{
			for (int i = 0; i < model.faces; i++)
			{
				aFib3_Arrays_180_190.Faces_180_190[i] = new int[6];
				for (int j = 0; j < 6; j++)
				{
					aFib3_Arrays_180_190.Faces_180_190[i][j] = 0;
				}
			}
		}

		//Get the relevant data
		GetOBJData(file, segmentStart, segmentFinish, aFib3_Arrays_180_190.Positions_180_190, aFib3_Arrays_180_190.Texels_180_190, aFib3_Arrays_180_190.Normals_180_190, aFib3_Arrays_180_190.Faces_180_190);
	}

	#pragma endregion AFib3_Array_Segments

}