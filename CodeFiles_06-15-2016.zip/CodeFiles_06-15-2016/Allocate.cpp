#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>

#include "Models.h"
#include "Arrays.h"
#include "Define.h"
#include "Allocate.h"

using namespace std;

namespace Inventum_VR
{
	void GetOBJInfo(string value, string segmentStart, string segmentFinish)
	{
		cout << "Get OBJ Info for " << value << " - " << segmentStart << endl;

		bool allowReading = false;

		//input stream to open the file
		ifstream stream;
		stream.open(value);

		//Check whether the file is corrupt or not
		if (!stream.good())
		{
			cout << "File is corrupt or some error opening the OBJ file";
			getchar();
			exit(EXIT_FAILURE);
		}

		//Parse through the file and get the number of vertices, normals, faces and so on
		while (!stream.eof())
		{
			string line;
			getline(stream, line);

			if (line.compare(segmentFinish) == 0)
				break;
			else if (line.compare(segmentStart) == 0 || allowReading)
			{
				allowReading = true;

				string type = line.substr(0, 2);

				if (type.compare("v ") == 0)
					model.positions++;
				else if (type.compare("vt") == 0)
					model.texels++;
				else if (type.compare("vn") == 0)
					model.normals++;
				else if (type.compare("f ") == 0)
					model.faces++;
			}
		}

		model.verticies = model.faces * 3;

		stream.close();
	}

	void AllocateModelsAndArrays(string name, string fileName, string fileSegmentStart, string fileSegmentFinish)
	{
		GetOBJInfo(fileName, fileSegmentStart, fileSegmentFinish);

		if (name.compare("AFib1") == 0)
		{
			AllocateAFib1(fileName, fileSegmentStart, fileSegmentFinish);
		}
		else if (name.compare("AFib2") == 0)
		{
			AllocateAFib2(fileName, fileSegmentStart, fileSegmentFinish);
		}
		else if (name.compare("AFib3") == 0)
		{
			AllocateAFib3(fileName, fileSegmentStart, fileSegmentFinish);
		}
	}

	void AllocateAFib1(string name, string fileSegmentStart, string fileSegmentFinish)
	{
		if (fileSegmentStart.compare("g _010_140") == 0)
		{
			Model_AssignSegment_010_140(model);
			AFib1_AssignSegment_010_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _030-040") == 0)
		{
			Model_AssignSegment_030_040(model);
			AFib1_AssignSegment_030_040(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _040-050") == 0)
		{
			Model_AssignSegment_040_050(model);
			AFib1_AssignSegment_040_050(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _050-060") == 0)
		{
			Model_AssignSegment_050_060(model);
			AFib1_AssignSegment_050_060(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _060-070") == 0)
		{
			Model_AssignSegment_060_070(model);
			AFib1_AssignSegment_060_070(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _070-080") == 0)
		{
			Model_AssignSegment_070_080(model);
			AFib1_AssignSegment_070_080(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _080-090") == 0)
		{
			Model_AssignSegment_080_090(model);
			AFib1_AssignSegment_080_090(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _090-100") == 0)
		{
			Model_AssignSegment_090_100(model);
			AFib1_AssignSegment_090_100(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _100-110") == 0)
		{
			Model_AssignSegment_100_110(model);
			AFib1_AssignSegment_100_110(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _110-120") == 0)
		{
			Model_AssignSegment_110_120(model);
			AFib1_AssignSegment_110_120(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _120-130") == 0)
		{
			Model_AssignSegment_120_130(model);
			AFib1_AssignSegment_120_130(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _130-140") == 0)
		{
			Model_AssignSegment_130_140(model);
			AFib1_AssignSegment_130_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _140-150") == 0)
		{
			Model_AssignSegment_140_150(model);
			AFib1_AssignSegment_140_150(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _150-160") == 0)
		{
			Model_AssignSegment_150_160(model);
			AFib1_AssignSegment_150_160(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _160-170") == 0)
		{
			Model_AssignSegment_160_170(model);
			AFib1_AssignSegment_160_170(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _170-180") == 0)
		{
			Model_AssignSegment_170_180(model);
			AFib1_AssignSegment_170_180(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _180-190") == 0)
		{
			Model_AssignSegment_180_190(model);
			AFib1_AssignSegment_180_190(name, fileSegmentStart, fileSegmentFinish);
		}
	}

	void AllocateAFib2(string name, string fileSegmentStart, string fileSegmentFinish)
	{
		if (fileSegmentStart.compare("g _010_140") == 0)
		{
			AFib2_AssignSegment_010_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _030-040") == 0)
		{
			AFib2_AssignSegment_030_040(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _040-050") == 0)
		{
			AFib2_AssignSegment_040_050(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _050-060") == 0)
		{
			AFib2_AssignSegment_050_060(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _060-070") == 0)
		{
			AFib2_AssignSegment_060_070(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _070-080") == 0)
		{
			AFib2_AssignSegment_070_080(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _080-090") == 0)
		{
			AFib2_AssignSegment_080_090(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _090-100") == 0)
		{
			AFib2_AssignSegment_090_100(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _100-110") == 0)
		{
			AFib2_AssignSegment_100_110(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _110-120") == 0)
		{
			AFib2_AssignSegment_110_120(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _120-130") == 0)
		{
			AFib2_AssignSegment_120_130(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _130-140") == 0)
		{
			AFib2_AssignSegment_130_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _140-150") == 0)
		{
			AFib2_AssignSegment_140_150(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _150-160") == 0)
		{
			AFib2_AssignSegment_150_160(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _160-170") == 0)
		{
			AFib2_AssignSegment_160_170(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _170-180") == 0)
		{
			AFib2_AssignSegment_170_180(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _180-190") == 0)
		{
			AFib2_AssignSegment_180_190(name, fileSegmentStart, fileSegmentFinish);
		}
	}

	void AllocateAFib3(string name, string fileSegmentStart, string fileSegmentFinish)
	{
		if (fileSegmentStart.compare("g _010_140") == 0)
		{
			AFib3_AssignSegment_010_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _030-040") == 0)
		{
			AFib3_AssignSegment_030_040(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _040-050") == 0)
		{
			AFib3_AssignSegment_040_050(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _050-060") == 0)
		{
			AFib3_AssignSegment_050_060(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _060-070") == 0)
		{
			AFib3_AssignSegment_060_070(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _070-080") == 0)
		{
			AFib3_AssignSegment_070_080(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _080-090") == 0)
		{
			AFib3_AssignSegment_080_090(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _090-100") == 0)
		{
			AFib3_AssignSegment_090_100(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _100-110") == 0)
		{
			AFib3_AssignSegment_100_110(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _110-120") == 0)
		{
			AFib3_AssignSegment_110_120(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _120-130") == 0)
		{
			AFib3_AssignSegment_120_130(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _130-140") == 0)
		{
			AFib3_AssignSegment_130_140(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _140-150") == 0)
		{
			AFib3_AssignSegment_140_150(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _150-160") == 0)
		{
			AFib3_AssignSegment_150_160(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _160-170") == 0)
		{
			AFib3_AssignSegment_160_170(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _170-180") == 0)
		{
			AFib3_AssignSegment_170_180(name, fileSegmentStart, fileSegmentFinish);
		}
		else if (fileSegmentStart.compare("g _180-190") == 0)
		{
			AFib3_AssignSegment_180_190(name, fileSegmentStart, fileSegmentFinish);
		}
	}
}

