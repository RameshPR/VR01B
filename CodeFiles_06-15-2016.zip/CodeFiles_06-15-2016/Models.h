namespace Inventum_VR
{
#ifndef Models_H
#define Models_H

	//Model structure
	typedef struct Model
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model;

	//Model structure
	typedef struct Model_010_140
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_010_140()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_010_140;

	//Model structure
	typedef struct Model_030_040
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_030_040()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_030_040;

	//Model structure
	typedef struct Model_040_050
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_040_050()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_040_050;

	//Model structure
	typedef struct Model_050_060
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_050_060()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_050_060;

	//Model structure
	typedef struct Model_060_070
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_060_070()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_060_070;

	//Model structure
	typedef struct Model_070_080
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_070_080()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_070_080;

	//Model structure
	typedef struct Model_080_090
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_080_090()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_080_090;

	//Model structure
	typedef struct Model_090_100
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_090_100()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_090_100;

	//Model structure
	typedef struct Model_100_110
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_100_110()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_100_110;

	//Model structure
	typedef struct Model_110_120
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_110_120()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_110_120;

	//Model structure
	typedef struct Model_120_130
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_120_130()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_120_130;

	//Model structure
	typedef struct Model_130_140
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_130_140()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_130_140;

	//Model structure
	typedef struct Model_140_150
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_140_150()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_140_150;

	//Model structure
	typedef struct Model_150_160
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_150_160()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_150_160;

	//Model structure
	typedef struct Model_160_170
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_160_170()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_160_170;

	//Model structure
	typedef struct Model_170_180
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_170_180()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_170_180;

	//Model structure
	typedef struct Model_180_190
	{
		int verticies;
		int positions;
		int texels;
		int normals;
		int faces;

		Model_180_190()
		{
			verticies = 0;
			positions = 0;
			texels = 0;
			normals = 0;
			faces = 0;
		}
	}Model_180_190;

#endif // !Models_H

	void Model_AssignSegment_010_140(Model model);
	void Model_AssignSegment_030_040(Model model);
	void Model_AssignSegment_040_050(Model model);
	void Model_AssignSegment_050_060(Model model);
	void Model_AssignSegment_060_070(Model model);
	void Model_AssignSegment_070_080(Model model);
	void Model_AssignSegment_080_090(Model model);
	void Model_AssignSegment_090_100(Model model);
	void Model_AssignSegment_100_110(Model model);
	void Model_AssignSegment_110_120(Model model);
	void Model_AssignSegment_120_130(Model model);
	void Model_AssignSegment_130_140(Model model);
	void Model_AssignSegment_140_150(Model model);
	void Model_AssignSegment_150_160(Model model);
	void Model_AssignSegment_160_170(Model model);
	void Model_AssignSegment_170_180(Model model);
	void Model_AssignSegment_180_190(Model model);
}