#include<string>

using namespace std;

namespace Inventum_VR
{

#ifndef Arrays_H
#define Arrays_H

	//AFib1 Array structure
	typedef struct AFib1_Arrays_010_140
	{
		//g _010_140
		double** Positions_010_140;
		double** Texels_010_140;
		double** Normals_010_140;
		int** Faces_010_140;
	}AFib1_Arrays_010_140;

	typedef struct AFib1_Arrays_030_040
	{
		//g _030-040
		double** Positions_030_040;
		double** Texels_030_040;
		double** Normals_030_040;
		int** Faces_030_040;
	}AFib1_Arrays_030_040;

	typedef struct AFib1_Arrays_040_050
	{
		//g _040-050
		double** Positions_040_050;
		double** Texels_040_050;
		double** Normals_040_050;
		int** Faces_040_050;
	}AFib1_Arrays_040_050;

	typedef struct AFib1_Arrays_050_060
	{
		//g _050-060
		double** Positions_050_060;
		double** Texels_050_060;
		double** Normals_050_060;
		int** Faces_050_060;
	}AFib1_Arrays_050_060;

	typedef struct AFib1_Arrays_060_070
	{
		//g _060-070
		double** Positions_060_070;
		double** Texels_060_070;
		double** Normals_060_070;
		int** Faces_060_070;
	}AFib1_Arrays_060_070;

	typedef struct AFib1_Arrays_070_080
	{
		//g _070-080
		double** Positions_070_080;
		double** Texels_070_080;
		double** Normals_070_080;
		int** Faces_070_080;
	}AFib1_Arrays_070_080;

	typedef struct AFib1_Arrays_080_090
	{
		//g _080-090
		double** Positions_080_090;
		double** Texels_080_090;
		double** Normals_080_090;
		int** Faces_080_090;
	}AFib1_Arrays_080_090;

	typedef struct AFib1_Arrays_090_100
	{
		//g _090-100
		double** Positions_090_100;
		double** Texels_090_100;
		double** Normals_090_100;
		int** Faces_090_100;
	}AFib1_Arrays_090_100;

	typedef struct AFib1_Arrays_100_110
	{
		//g _100-110
		double** Positions_100_110;
		double** Texels_100_110;
		double** Normals_100_110;
		int** Faces_100_110;
	}AFib1_Arrays_100_110;

	typedef struct AFib1_Arrays_110_120
	{
		//g _110-120
		double** Positions_110_120;
		double** Texels_110_120;
		double** Normals_110_120;
		int** Faces_110_120;
	}AFib1_Arrays_110_120;

	typedef struct AFib1_Arrays_120_130
	{
		//g _120-130
		double** Positions_120_130;
		double** Texels_120_130;
		double** Normals_120_130;
		int** Faces_120_130;
	}AFib1_Arrays_120_130;

	typedef struct AFib1_Arrays_130_140
	{
		//g _130-140
		double** Positions_130_140;
		double** Texels_130_140;
		double** Normals_130_140;
		int** Faces_130_140;
	}AFib1_Arrays_130_140;

	typedef struct AFib1_Arrays_140_150
	{
		//g _140-150
		double** Positions_140_150;
		double** Texels_140_150;
		double** Normals_140_150;
		int** Faces_140_150;
	}AFib1_Arrays_140_150;

	typedef struct AFib1_Arrays_150_160
	{
		//g _150-160
		double** Positions_150_160;
		double** Texels_150_160;
		double** Normals_150_160;
		int** Faces_150_160;
	}AFib1_Arrays_150_160;

	typedef struct AFib1_Arrays_160_170
	{
		//g _160-170
		double** Positions_160_170;
		double** Texels_160_170;
		double** Normals_160_170;
		int** Faces_160_170;
	}AFib1_Arrays_160_170;

	typedef struct AFib1_Arrays_170_180
	{
		//g _170-180
		double** Positions_170_180;
		double** Texels_170_180;
		double** Normals_170_180;
		int** Faces_170_180;
	}AFib1_Arrays_170_180;

	typedef struct AFib1_Arrays_180_190
	{
		//g _180-190
		double** Positions_180_190;
		double** Texels_180_190;
		double** Normals_180_190;
		int** Faces_180_190;
	}AFib1_Arrays_180_190;

	//AFib2 Array structure
	typedef struct AFib2_Arrays_010_140
	{
		//g _010_140
		double** Positions_010_140;
		double** Texels_010_140;
		double** Normals_010_140;
		int** Faces_010_140;
	}AFib2_Arrays_010_140;

	typedef struct AFib2_Arrays_030_040
	{
		//g _030-040
		double** Positions_030_040;
		double** Texels_030_040;
		double** Normals_030_040;
		int** Faces_030_040;
	}AFib2_Arrays_030_040;

	typedef struct AFib2_Arrays_040_050
	{
		//g _040-050
		double** Positions_040_050;
		double** Texels_040_050;
		double** Normals_040_050;
		int** Faces_040_050;
	}AFib2_Arrays_040_050;

	typedef struct AFib2_Arrays_050_060
	{
		//g _050-060
		double** Positions_050_060;
		double** Texels_050_060;
		double** Normals_050_060;
		int** Faces_050_060;
	}AFib2_Arrays_050_060;

	typedef struct AFib2_Arrays_060_070
	{
		//g _060-070
		double** Positions_060_070;
		double** Texels_060_070;
		double** Normals_060_070;
		int** Faces_060_070;
	}AFib2_Arrays_060_070;

	typedef struct AFib2_Arrays_070_080
	{
		//g _070-080
		double** Positions_070_080;
		double** Texels_070_080;
		double** Normals_070_080;
		int** Faces_070_080;
	}AFib2_Arrays_070_080;

	typedef struct AFib2_Arrays_080_090
	{
		//g _080-090
		double** Positions_080_090;
		double** Texels_080_090;
		double** Normals_080_090;
		int** Faces_080_090;
	}AFib2_Arrays_080_090;

	typedef struct AFib2_Arrays_090_100
	{
		//g _090-100
		double** Positions_090_100;
		double** Texels_090_100;
		double** Normals_090_100;
		int** Faces_090_100;
	}AFib2_Arrays_090_100;

	typedef struct AFib2_Arrays_100_110
	{
		//g _100-110
		double** Positions_100_110;
		double** Texels_100_110;
		double** Normals_100_110;
		int** Faces_100_110;
	}AFib2_Arrays_100_110;

	typedef struct AFib2_Arrays_110_120
	{
		//g _110-120
		double** Positions_110_120;
		double** Texels_110_120;
		double** Normals_110_120;
		int** Faces_110_120;
	}AFib2_Arrays_110_120;

	typedef struct AFib2_Arrays_120_130
	{
		//g _120-130
		double** Positions_120_130;
		double** Texels_120_130;
		double** Normals_120_130;
		int** Faces_120_130;
	}AFib2_Arrays_120_130;

	typedef struct AFib2_Arrays_130_140
	{
		//g _130-140
		double** Positions_130_140;
		double** Texels_130_140;
		double** Normals_130_140;
		int** Faces_130_140;
	}AFib2_Arrays_130_140;

	typedef struct AFib2_Arrays_140_150
	{
		//g _140-150
		double** Positions_140_150;
		double** Texels_140_150;
		double** Normals_140_150;
		int** Faces_140_150;
	}AFib2_Arrays_140_150;

	typedef struct AFib2_Arrays_150_160
	{
		//g _150-160
		double** Positions_150_160;
		double** Texels_150_160;
		double** Normals_150_160;
		int** Faces_150_160;
	}AFib2_Arrays_150_160;

	typedef struct AFib2_Arrays_160_170
	{
		//g _160-170
		double** Positions_160_170;
		double** Texels_160_170;
		double** Normals_160_170;
		int** Faces_160_170;
	}AFib2_Arrays_160_170;

	typedef struct AFib2_Arrays_170_180
	{
		//g _170-180
		double** Positions_170_180;
		double** Texels_170_180;
		double** Normals_170_180;
		int** Faces_170_180;
	}AFib2_Arrays_170_180;

	typedef struct AFib2_Arrays_180_190
	{
		//g _180-190
		double** Positions_180_190;
		double** Texels_180_190;
		double** Normals_180_190;
		int** Faces_180_190;
	}AFib2_Arrays_180_190;

	//AFib3 Array structure
	typedef struct AFib3_Arrays_010_140
	{
		//g _010_140
		double** Positions_010_140;
		double** Texels_010_140;
		double** Normals_010_140;
		int** Faces_010_140;
	}AFib3_Arrays_010_140;

	typedef struct AFib3_Arrays_030_040
	{
		//g _030-040
		double** Positions_030_040;
		double** Texels_030_040;
		double** Normals_030_040;
		int** Faces_030_040;
	}AFib3_Arrays_030_040;

	typedef struct AFib3_Arrays_040_050
	{
		//g _040-050
		double** Positions_040_050;
		double** Texels_040_050;
		double** Normals_040_050;
		int** Faces_040_050;
	}AFib3_Arrays_040_050;

	typedef struct AFib3_Arrays_050_060
	{
		//g _050-060
		double** Positions_050_060;
		double** Texels_050_060;
		double** Normals_050_060;
		int** Faces_050_060;
	}AFib3_Arrays_050_060;

	typedef struct AFib3_Arrays_060_070
	{
		//g _060-070
		double** Positions_060_070;
		double** Texels_060_070;
		double** Normals_060_070;
		int** Faces_060_070;
	}AFib3_Arrays_060_070;

	typedef struct AFib3_Arrays_070_080
	{
		//g _070-080
		double** Positions_070_080;
		double** Texels_070_080;
		double** Normals_070_080;
		int** Faces_070_080;
	}AFib3_Arrays_070_080;

	typedef struct AFib3_Arrays_080_090
	{
		//g _080-090
		double** Positions_080_090;
		double** Texels_080_090;
		double** Normals_080_090;
		int** Faces_080_090;
	}AFib3_Arrays_080_090;

	typedef struct AFib3_Arrays_090_100
	{
		//g _090-100
		double** Positions_090_100;
		double** Texels_090_100;
		double** Normals_090_100;
		int** Faces_090_100;
	}AFib3_Arrays_090_100;

	typedef struct AFib3_Arrays_100_110
	{
		//g _100-110
		double** Positions_100_110;
		double** Texels_100_110;
		double** Normals_100_110;
		int** Faces_100_110;
	}AFib3_Arrays_100_110;

	typedef struct AFib3_Arrays_110_120
	{
		//g _110-120
		double** Positions_110_120;
		double** Texels_110_120;
		double** Normals_110_120;
		int** Faces_110_120;
	}AFib3_Arrays_110_120;

	typedef struct AFib3_Arrays_120_130
	{
		//g _120-130
		double** Positions_120_130;
		double** Texels_120_130;
		double** Normals_120_130;
		int** Faces_120_130;
	}AFib3_Arrays_120_130;

	typedef struct AFib3_Arrays_130_140
	{
		//g _130-140
		double** Positions_130_140;
		double** Texels_130_140;
		double** Normals_130_140;
		int** Faces_130_140;
	}AFib3_Arrays_130_140;

	typedef struct AFib3_Arrays_140_150
	{
		//g _140-150
		double** Positions_140_150;
		double** Texels_140_150;
		double** Normals_140_150;
		int** Faces_140_150;
	}AFib3_Arrays_140_150;

	typedef struct AFib3_Arrays_150_160
	{
		//g _150-160
		double** Positions_150_160;
		double** Texels_150_160;
		double** Normals_150_160;
		int** Faces_150_160;
	}AFib3_Arrays_150_160;

	typedef struct AFib3_Arrays_160_170
	{
		//g _160-170
		double** Positions_160_170;
		double** Texels_160_170;
		double** Normals_160_170;
		int** Faces_160_170;
	}AFib3_Arrays_160_170;

	typedef struct AFib3_Arrays_170_180
	{
		//g _170-180
		double** Positions_170_180;
		double** Texels_170_180;
		double** Normals_170_180;
		int** Faces_170_180;
	}AFib3_Arrays_170_180;

	typedef struct AFib3_Arrays_180_190
	{
		//g _180-190
		double** Positions_180_190;
		double** Texels_180_190;
		double** Normals_180_190;
		int** Faces_180_190;
	}AFib3_Arrays_180_190;

#endif // !Arrays_H



	void GetOBJData(string file, string segmentStart, string segmentFinish, double** positions, double** texels, double** normals, int** faces);

	void AFib1_AssignSegment_010_140(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_030_040(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_040_050(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_050_060(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_060_070(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_070_080(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_080_090(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_090_100(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_100_110(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_110_120(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_120_130(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_130_140(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_140_150(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_150_160(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_160_170(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_170_180(string file, string segmentStart, string segmentFinish);
	void AFib1_AssignSegment_180_190(string file, string segmentStart, string segmentFinish);

	void AFib2_AssignSegment_010_140(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_030_040(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_040_050(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_050_060(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_060_070(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_070_080(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_080_090(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_090_100(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_100_110(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_110_120(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_120_130(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_130_140(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_140_150(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_150_160(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_160_170(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_170_180(string file, string segmentStart, string segmentFinish);
	void AFib2_AssignSegment_180_190(string file, string segmentStart, string segmentFinish);

	void AFib3_AssignSegment_010_140(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_030_040(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_040_050(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_050_060(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_060_070(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_070_080(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_080_090(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_090_100(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_100_110(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_110_120(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_120_130(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_130_140(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_140_150(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_150_160(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_160_170(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_170_180(string file, string segmentStart, string segmentFinish);
	void AFib3_AssignSegment_180_190(string file, string segmentStart, string segmentFinish);
}