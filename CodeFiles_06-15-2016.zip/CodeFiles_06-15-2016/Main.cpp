#include<iostream>

#include "Define.h"
#include "Allocate.h"
#include "Deallocate.h"

using namespace std;

namespace Inventum_VR
{
	int main(int argc, const char * argv[])
	{
		int fileCounter = 0;
		int segmentCounter = 0;

		bool isPositions = false, isTexels = false, isNormals = false, isFaces = false;

		//Creating file setup
		string sourceNames[] = { "AFib1", "AFib2", "AFib3" };
		string sourceOBJSegments[] = { "g _010_140", "g _030-040", "g _040-050", "g _050-060", "g _060-070", "g _070-080", "g _080-090", "g _090-100", "g _100-110", "g _110-120", "g _120-130", "g _130-140", "g _140-150", "g _150-160", "g _160-170", "g _170-180", "g _180-190" };
		string name, fileOBJPath, fileOBJSegmentStart, fileOBJSegmentFinish;

		while (fileCounter < 1)
		{
			name = sourceNames[fileCounter];
			fileOBJPath = "source/" + name + ".obj";

			while (segmentCounter < 17)
			{
				fileOBJSegmentStart = sourceOBJSegments[segmentCounter];

				if (segmentCounter == 16)
					fileOBJSegmentFinish = "End";
				else
					fileOBJSegmentFinish = sourceOBJSegments[segmentCounter + 1];

				//check to see the numbers
				cout << "OBJ Info" << endl;
				cout << "Positions: " << model.positions << endl;
				cout << "Texels: " << model.texels << endl;
				cout << "Normals: " << model.normals << endl;
				cout << "Faces: " << model.faces << endl;
				cout << "Vertices: " << model.verticies << endl;
				cout << "\n" << endl;

				//delcare the arrary based on the model data
				if (model.positions != 0 && model.texels != 0 && model.normals != 0 && model.faces != 0 && model.verticies != 0)
				{
					isPositions = true; isTexels = true; isNormals = true; isFaces = true;

					cout << "Got all data \n" << endl;

					//Assign values to the global arrays to compute average coordinates
					AllocateModelsAndArrays(name, fileOBJPath, fileOBJSegmentStart, fileOBJSegmentFinish);
				}
				else if (model.positions != 0 && model.texels != 0 && model.faces != 0)
				{
					isPositions = true; isTexels = true; isFaces = true;

					cout << "Missing normals \n" << endl;

					//Assign values to the global arrays to compute average coordinates
					AllocateModelsAndArrays(name, fileOBJPath, fileOBJSegmentStart, fileOBJSegmentFinish);
				}
				else if (model.positions != 0 && model.normals != 0 && model.faces != 0)
				{
					isPositions = true;
					isNormals = true;
					isFaces = true;

					cout << "Missing texels \n" << endl;

					//Assign values to the global arrays to compute average coordinates
					AllocateModelsAndArrays(name, fileOBJPath, fileOBJSegmentStart, fileOBJSegmentFinish);
				}

				model.positions = 0;
				model.texels = 0;
				model.normals = 0;
				model.faces = 0;
				model.verticies = 0;
				segmentCounter++;
			}

			//Check to see correctness of the data -- Checking the first entry
			cout << "Model Data" << endl;
			cout << "Position: " << aFib1_Arrays_010_140.Positions_010_140[0][0] << "x " << aFib1_Arrays_010_140.Positions_010_140[0][1] << "y " << aFib1_Arrays_010_140.Positions_010_140[0][2] << "z" << endl;
			cout << "Normals: " << aFib1_Arrays_010_140.Texels_010_140[0][0] << "u " << aFib1_Arrays_010_140.Texels_010_140[0][1] << "v " << endl;
			cout << "Faces: " << aFib1_Arrays_010_140.Faces_010_140[0][0] << "p " << aFib1_Arrays_010_140.Faces_010_140[0][1] << "t " << aFib1_Arrays_010_140.Faces_010_140[0][2] << "n" << endl;
			cout << "\n" << endl;

			segmentCounter = 0;
			fileCounter++;
		}
		getchar();
		return 0;
	}
}
